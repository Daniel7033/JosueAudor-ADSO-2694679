import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  BrowserAnimationsModule,
  InjectableAnimationEngine,
  NoopAnimationsModule,
  provideAnimations,
  provideNoopAnimations
} from "./chunk-DWWBHDSS.js";
import "./chunk-LHK3B5JD.js";
import "./chunk-63K3XXRW.js";
import "./chunk-5G7WB3EG.js";
import {
  ANIMATION_MODULE_TYPE
} from "./chunk-X6UFMS2E.js";
import "./chunk-NQ4HTGF6.js";
export {
  ANIMATION_MODULE_TYPE,
  BrowserAnimationsModule,
  NoopAnimationsModule,
  provideAnimations,
  provideNoopAnimations,
  InjectableAnimationEngine as ɵInjectableAnimationEngine
};
//# sourceMappingURL=@angular_platform-browser_animations.js.map
