import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Usuario } from '../models/usuario';

@Injectable({
  providedIn: 'root'
})
export class UsuarioService {

  private apiUrl = 'http://localhost:7033/tiendabeats/usuario';

  constructor(private http:HttpClient) { }

  //Método mostrar todo
  getAll(): Observable<Usuario[]>{
    return this.http.get<Usuario[]>(this.apiUrl);
  }

  //Método de busqueda de un solo dato por id
  getFingById(id:number): Observable<Usuario>{
    return this.http.get<Usuario>(`${this.apiUrl}/${id}`);
  }

  //Método de guardado
  save(usuario:Usuario): Observable<Usuario>{
    return this.http.post<Usuario>(this.apiUrl, usuario);
  }

  //Método de actualización de datos
  update(usuario:Usuario){
    return this.http.put(this.apiUrl, usuario);
  }

  delete(id:number){
    return this.http.delete(`${this.apiUrl}/${id}`)
  }
}
