package com.sena.tiendabeats.IService;

import com.sena.tiendabeats.Entity.Usuario;

public interface IUsuarioService extends IBaseService<Usuario>{
    
}
