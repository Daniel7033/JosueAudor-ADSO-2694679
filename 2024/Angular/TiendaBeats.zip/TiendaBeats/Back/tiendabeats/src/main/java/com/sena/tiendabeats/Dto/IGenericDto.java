package com.sena.tiendabeats.Dto;

public interface IGenericDto {
    Long getId();
}
