package com.sena.ventaautos.IService;

import com.sena.ventaautos.Entity.Consecionario;

public interface IConsecionarioService extends IBaseService<Consecionario>{
    // Apartir de aquí irian los "DTO" en caso que sean requeridos
    // ...
}
