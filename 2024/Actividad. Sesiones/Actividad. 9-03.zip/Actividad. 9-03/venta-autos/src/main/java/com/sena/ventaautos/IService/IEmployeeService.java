package com.sena.ventaautos.IService;

import com.sena.ventaautos.Entity.Employee;

public interface IEmployeeService extends IBaseService<Employee>{
    // Apartir de aquí irian los "DTO" en caso que sean requeridos
    // ...
}
