package com.sena.ventaautos.IService;

import com.sena.ventaautos.Entity.Cars;

public interface ICarsService extends IBaseService<Cars>{
    // Apartir de aquí irian los "DTO" en caso que sean requeridos
    // ...
}
