package com.sena.ventaautos.IRepository;

import org.springframework.stereotype.Repository;

import com.sena.ventaautos.Entity.Consecionario;

@Repository
public interface IConsecionarioRepository extends IBaseRepository<Consecionario, Long>{
    
}
