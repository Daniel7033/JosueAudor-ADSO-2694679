package com.sena.ventaautos.IService;

import com.sena.ventaautos.Entity.Customer;

public interface ICustomerService extends IBaseService<Customer>{
    // Apartir de aquí irian los "DTO" en caso que sean requeridos
    // ...
}
