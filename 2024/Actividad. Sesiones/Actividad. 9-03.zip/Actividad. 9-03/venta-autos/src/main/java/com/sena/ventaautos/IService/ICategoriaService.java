package com.sena.ventaautos.IService;

import com.sena.ventaautos.Entity.Categoria;

public interface ICategoriaService extends IBaseService<Categoria>{
    // Apartir de aquí irian los "DTO" en caso que sean requeridos
    // ...
}
