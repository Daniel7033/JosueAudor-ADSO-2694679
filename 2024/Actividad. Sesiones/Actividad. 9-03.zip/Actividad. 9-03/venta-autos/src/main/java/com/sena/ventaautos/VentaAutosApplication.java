package com.sena.ventaautos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VentaAutosApplication {

	public static void main(String[] args) {
		SpringApplication.run(VentaAutosApplication.class, args);
	}

}
