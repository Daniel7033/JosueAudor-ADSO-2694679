package com.sena.ventaautos.IRepository;

import org.springframework.stereotype.Repository;

import com.sena.ventaautos.Entity.Categoria;

@Repository
public interface ICategoriaRepository extends IBaseRepository<Categoria, Long>{
    
}
