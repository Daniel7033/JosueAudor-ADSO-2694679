/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package View;

import Class.ClassRango2;

/**
 *
 * @author Stork
 */
public class ViewRango2 {
    public static void main(String[] args) {
        ClassRango2 rango = new ClassRango2();
        
        rango.setMensaje("Dígite un número: ");
        rango.Mostrar();
    }
}
