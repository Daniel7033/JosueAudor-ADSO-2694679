/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package View;

import Class.ClassAbsoluto;

/**
 *
 * @author Stork
 */
public class ViewAbsoluto {

    public static void main(String[] args) {
        ClassAbsoluto x = new ClassAbsoluto();
        
        x.setMensaje("Dígite un Número: ");
        x.Mostrar();
    }
}
