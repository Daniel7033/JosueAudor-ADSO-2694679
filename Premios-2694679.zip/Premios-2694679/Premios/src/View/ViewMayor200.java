/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package View;

import Class.ClassMayor200;

/**
 *
 * @author Stork
 */
public class ViewMayor200 {

    public static void main(String[] args) {
        ClassMayor200 x = new ClassMayor200();

        x.setMensaje("Dígite un Número: ");
        x.Mostrar();

    }
}
