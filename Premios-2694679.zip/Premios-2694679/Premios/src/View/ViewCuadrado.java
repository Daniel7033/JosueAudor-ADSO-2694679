/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package View;

import Class.ClassCuadrado;

/**
 *
 * @author Stork
 */
public class ViewCuadrado {
    public static void main(String[] args) {
        
        ClassCuadrado x = new ClassCuadrado();
        
        x.setMensaje("Dígite un número: ");
        x.Mostrar();
        
    }
}
