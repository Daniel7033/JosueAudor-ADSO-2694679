/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package View;

import Class.ClassPosNeg;

/**
 *
 * @author Stork
 */
public class ViewPosNeg {
    public static void main(String[] args) {
        ClassPosNeg x = new ClassPosNeg();
        
        x.setMensaje("Dígite un número: ");
        x.Mostrar();
    }
}
