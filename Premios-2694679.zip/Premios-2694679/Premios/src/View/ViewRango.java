/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package View;

import Class.ClassRango;

/**
 *
 * @author Stork
 */
public class ViewRango {
    public static void main(String[] args) {
        ClassRango x = new ClassRango();
        
        x.setMensaje("Dígite un número");
        x.Mostrar();
    }
}
