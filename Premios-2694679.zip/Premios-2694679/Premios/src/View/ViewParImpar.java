
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package View;


import Class.ClassParImpar;

/**
 *
 * @author Stork
 */
public class ViewParImpar {
    public static void main(String[] args) {
        ClassParImpar x = new ClassParImpar();
        
        x.setMensaje("Dígite un número");
        x.Capturar();
        
    }
}
