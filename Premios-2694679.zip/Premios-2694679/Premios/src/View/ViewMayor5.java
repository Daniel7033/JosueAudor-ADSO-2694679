/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package View;

import Class.ClassMayor5;

/**
 *
 * @author Stork
 */
public class ViewMayor5 {
    
        
    public static void main(String[] args) {
        
        ClassMayor5 x = new ClassMayor5();
        x.setMensaje("Digite un número");
        
        x.Mostrar();
        
        
    }
}
